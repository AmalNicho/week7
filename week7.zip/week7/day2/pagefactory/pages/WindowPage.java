package week7.day2.pagefactory.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import week7.day2.pagefactory.base.Base;

public class WindowPage extends Base {
	
	@FindBy(how=How.XPATH, using="//a[contains(text(),'CRM/SFA')]") private WebElement elementCRM;
	
	public WindowPage(ChromeDriver Driver) {
		this.driver=Driver;
		PageFactory.initElements(driver, this);
	}
	
	public HomePage leaftabs() {
		elementCRM.click();
return new HomePage(driver);
	}

}
