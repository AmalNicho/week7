package week7.day2.pagefactory.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import week7.day2.pagefactory.base.Base;

public class LeadsPage extends Base {
	
	@FindBy(how=How.XPATH,using="//a[text()='Create Lead']") private WebElement elementCreateLeads;
	@FindBy(how=How.XPATH, using="//a[text()='Find Leads']") private WebElement elementFindLeads;
	@FindBy(how=How.XPATH,using="//a[text()='Merge Leads']") private WebElement elementMergeLeads;
	
	public LeadsPage(ChromeDriver Driver) {
		this.driver=Driver;
		PageFactory.initElements(driver, this);
	}
	
	public CreateLeads Leadss() {
		driver.findElement(By.xpath("//a[text()='Create Lead']")).click();
		return new CreateLeads(driver);
	}

	public FindLeads FLeads() {
		driver.findElement(By.xpath("//a[text()='Find Leads']")).click();
		return new FindLeads(driver);
	}
	
	public MergeLeads MLeads() {
		driver.findElement(By.xpath("//a[text()='Merge Leads']")).click();
		return new MergeLeads(driver);
	}
}
