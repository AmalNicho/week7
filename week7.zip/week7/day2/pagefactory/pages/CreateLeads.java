package week7.day2.pagefactory.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import week7.day2.pagefactory.base.Base;



public class CreateLeads extends Base {
	
	@FindBy(how=How.ID,using="createLeadForm_companyName") private WebElement elementcompany;
	@FindBy(how=How.ID,using="createLeadForm_firstName") private WebElement elementFirstName;
	@FindBy(how=How.ID,using="createLeadForm_lastName") private WebElement elementLastName;
	@FindBy(how=How.XPATH,using="//input[@name='submitButton']") private WebElement elementsubmit;
	
	public CreateLeads(ChromeDriver Inwarddriver)
	{
		this.driver=Inwarddriver;
		PageFactory.initElements(driver,this);
	}
	
	
	public CreateLeads typecompanyname(String Cname) {
		elementcompany.sendKeys(Cname);
		return this;
	}

	public CreateLeads typefirstname(String Fname) {
		elementFirstName.sendKeys(Fname);
		return this;
	}

	public CreateLeads typelastname(String Lname) {
		elementLastName.sendKeys(Lname);
		return this;
	}

	public ViewLeads cli_submit() {
		elementsubmit.click();
		return new ViewLeads(driver);
	}
}
