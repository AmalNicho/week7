package week7.day2.pagefactory.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import week7.day2.pagefactory.base.Base;

public class DupLeads extends Base {
	
	@FindBy(how=How.ID,using="createLeadForm_primaryPhoneNumber") private WebElement elementphonenumber;
	@FindBy(how=How.XPATH,using="//input[@value='Create Lead']") private WebElement elementsubmit;
	
	public DupLeads(ChromeDriver inwarddriver) {
		this.driver=inwarddriver;
		PageFactory.initElements(driver,this);
	}
	
	public DupLeads typephonenumber(String Phonenumber) {
		
		elementphonenumber.sendKeys(Phonenumber);
		return this;
	}
	
	public ViewLeads leads_submit( ) {
		elementsubmit.click();
		return new ViewLeads(driver);
	}

}
