package week7.day2.pagefactory.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import week7.day2.pagefactory.base.Base;

public class LoginPage extends Base {

	@FindBy(how=How.ID,using="username") private WebElement elementusername;
	@FindBy(how=How.ID,using="password") private WebElement elementpassword;
	@FindBy(how=How.CLASS_NAME,using="decorativeSubmit") private WebElement elementsubmit;

		
	public LoginPage(ChromeDriver Driver) {
		this.driver=Driver;
		PageFactory.initElements(driver, this);
		
		
	}
	
	public LoginPage typeusername(String UserName) {
		elementusername.sendKeys(UserName);
		return this;
	}

	public LoginPage typepassword(String PassWord) {
		elementpassword.sendKeys(PassWord);
		return this;
	}
	
	public WindowPage clicksubmit() {
		elementsubmit.click();
	return new WindowPage(driver);
	}
}

	