package week7.day2.pagefactory.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import week7.day2.pagefactory.base.Base;

public class ViewLeads extends Base {
	
@FindBy(how=How.XPATH,using="//a[text()='Edit']") private WebElement elementElead;
@FindBy(how=How.XPATH,using="//a[text()='Duplicate Lead']") private WebElement elementDuplead;
@FindBy(how=How.XPATH,using="//a[text()='Delete']") private WebElement elementDellead;
	
	public ViewLeads(ChromeDriver Driver) {
		this.driver=Driver;
		PageFactory.initElements(driver, this);
	}
	
	
	public void Vlead() {
			
		Assert.assertEquals(driver.getTitle(),"View Lead | opentaps CRM");
	}
	
	public EditPage Elead() {
		elementElead.click();
		return new EditPage(driver);
	}
	
	public DupLeads Duplead() {
		elementDuplead.click();
		return new  DupLeads(driver);
	}
	
	public LeadsPage Dellead() {
		elementDellead.click();
		return new LeadsPage(driver);
	}

}
