package week7.day2.pagefactory.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import week7.day2.pagefactory.base.Base;

public class HomePage extends Base {
	
	@FindBy(how=How.XPATH,using="//a[text()='Leads']") private WebElement elementClickleads;
	
	public HomePage(ChromeDriver Driver) {
		this.driver=Driver;
		PageFactory.initElements(driver, this);
	}
	
	public LeadsPage clickleads() {
		elementClickleads.click();
		return new LeadsPage(driver);
	}

}
