package week7.day2.pagefactory.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import week7.day2.pagefactory.base.Base;

public class FindLeads extends Base {
	
	@FindBy(how=How.XPATH,using="(//input[@name='firstName'])[3]") private WebElement elementfirstname;
	@FindBy(how=How.XPATH,using="(//input[@name='lastName'])[3]") private WebElement elementlastname;
	@FindBy(how=How.XPATH,using="(//input[@name='companyName'])[2]") private WebElement elementcompanyname;
	@FindBy(how=How.XPATH,using="//button[text()='Find Leads']") private WebElement elementclick;
	@FindBy(how=How.XPATH,using="//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a") private WebElement elementSelleads;
	
	public FindLeads(ChromeDriver Driver) {
	this.driver=Driver;
	PageFactory.initElements(driver, this);
	}
	
	public FindLeads Flead(String Fname) {
		elementfirstname.sendKeys(Fname);
		return this;
	}

	public FindLeads Llead(String Lname) {
		elementlastname.sendKeys(Lname);
		return this;
	}
	
	public FindLeads Clead(String Cname) {
		elementcompanyname.sendKeys(Cname);
		return this;
	}
	
	public FindLeads Cli_FLeads() throws InterruptedException {
		elementclick.click();
		Thread.sleep(2000);
		return this;
	}
	
public ViewLeads sel_leads() {
	elementSelleads.click();
	return new ViewLeads(driver);
}
}
