package week7.day2.pagefactory.pages;

import java.util.ArrayList;
import java.util.Set;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import week7.day2.pagefactory.base.Base;

public class MergeLeads extends Base {
	
	@FindBy(how=How.XPATH,using="(//img[@src='/images/fieldlookup.gif'])[1]") private WebElement elementfirstcontact;
	@FindBy(how=How.XPATH,using="(//img[@src='/images/fieldlookup.gif'])[2]") private WebElement elementseondcontact;
	@FindBy(how=How.XPATH,using="//input[@name='firstName']") private WebElement elementfirstname;
	@FindBy(how=How.XPATH,using="//input[@name='lastName']") private WebElement elementlastname;
	@FindBy(how=How.XPATH,using="//input[@name='companyName']']") private WebElement elementcompanyname;
	@FindBy(how=How.XPATH,using="//button[text()='Find Leads']") private WebElement elementfind;
	@FindBy(how=How.XPATH,using="(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]") private WebElement elementmerge;
	@FindBy(how=How.XPATH,using="//a[text()='Merge']")private WebElement elementclimerge;
	
	
	public MergeLeads(ChromeDriver Driver) {
		this.driver=Driver;
		PageFactory.initElements(driver,this);
	}

	ArrayList<String> arrayList = new ArrayList<String>();

	public MergeLeads find_first_contact() {
		elementfirstcontact.click();
		return this;

	}
	
	public MergeLeads find_second_contact() {
		elementseondcontact.click();
		return this;

	}

	public MergeLeads window_handle(int windownumber) {
		Set<String> windowHandles = driver.getWindowHandles();
		arrayList.clear();
		arrayList.addAll(windowHandles);
		driver.switchTo().window(arrayList.get(windownumber));
		
		return this;
	}

	public MergeLeads typefirstname(String fname) {
		elementfirstname.sendKeys(fname);
		return this;
	}

	public MergeLeads typelastname(String lname) {
		elementlastname.sendKeys(lname);
		return this;
	}

	public MergeLeads typecompanyname(String cname) {
		elementcompanyname.sendKeys(cname);
		return this;
	}

	public MergeLeads find() throws InterruptedException {
		elementfind.click();
		Thread.sleep(2000);
		return this;
	}

	public MergeLeads select_id() throws InterruptedException {
		elementmerge.click();
		
		return this;
	}

	public MergeLeads base_window() {
		driver.switchTo().window(arrayList.get(0));
		return this;
	}

	public ViewLeads click_merge() {
		elementclimerge.click();
		driver.switchTo().alert().accept();
		return new ViewLeads(driver);
	}

}