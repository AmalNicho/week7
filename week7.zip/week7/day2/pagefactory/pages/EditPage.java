package week7.day2.pagefactory.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import week7.day2.pagefactory.base.Base;

public class EditPage extends Base {
	
	@FindBy(how=How.ID,using="updateLeadForm_industryEnumId") private WebElement elementindustry;
	@FindBy(how=How.ID,using="updateLeadForm_generalProfTitle") private WebElement elementtitle;
	@FindBy(how=How.XPATH,using="//input[@value='Update']") private WebElement elementupdate;
	
	public EditPage(ChromeDriver Idriver) {
		this.driver=Idriver;
		PageFactory.initElements(driver,this);
	}

	public EditPage ELeadss(String Industry) {

		
		Select x = new Select(elementindustry);
		x.selectByVisibleText(Industry);
		return this;

	}

	public EditPage title(String title) {
		elementtitle.sendKeys(title);
		return this;
	}

	public ViewLeads Cli_Update() {
		elementupdate.click();
		return new ViewLeads(driver);
	}

}
