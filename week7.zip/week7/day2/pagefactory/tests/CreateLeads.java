package week7.day2.pagefactory.tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.day2.pagefactory.base.Base;
import week7.day2.pagefactory.pages.LoginPage;

public class CreateLeads extends Base {
	
	@BeforeTest
	public void Createfile() {
		SheetName="CreateLead";
	
	}
	
	@Test(dataProvider="setfile")
	public void CLeadsPostive(String Cname,String Fname,String Lname) {
		
		new LoginPage(driver)
		.typeusername(UserName)
		.typepassword(PassWord)
		.clicksubmit()
		.leaftabs()
		.clickleads()
		.Leadss()
		.typecompanyname(Cname)
		.typefirstname(Fname)
		.typelastname(Lname)
		.cli_submit();
		
	}

}
