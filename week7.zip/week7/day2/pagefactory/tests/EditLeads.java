package week7.day2.pagefactory.tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.day2.pagefactory.base.Base;

import week7.day2.pagefactory.pages.LoginPage;

public class EditLeads extends Base {

	@BeforeTest
	public void SetEname( ) {
		SheetName="EditLead";
	}
	
	@Test(dataProvider="setfile")
	public void ELeads(String Cname,String Fname,String Lname,String Industry,String Title) throws InterruptedException
	{
		new LoginPage(driver)
		.typeusername(UserName)
		.typepassword(PassWord)
		.clicksubmit()
		.leaftabs()
		.clickleads()
		.FLeads()
		.Flead(Fname)
		.Llead(Lname)
		.Clead(Cname)
		.Cli_FLeads()
		.sel_leads()
		.Elead().ELeadss(Industry)
		.title(Title)
		.Cli_Update()
		.Vlead();
		
	}
	}
	

