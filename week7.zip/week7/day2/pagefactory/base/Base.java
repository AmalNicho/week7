package week7.day2.pagefactory.base;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;
import week7.day2.pagefactory.utility.Readfile;

public class Base {

	public ChromeDriver driver;
	public String SheetName;
	public static String UserName;
	public static String PassWord;

	@Parameters({ "URL","Username","Password" })
	@BeforeMethod
	public void Pre(String Url,String Username,String Password) throws Exception {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get(Url);
		driver.manage().window().maximize();
		UserName=Username;
		PassWord=Password;

	}

	@DataProvider
	public String[][] setfile() throws IOException {
		String[][] eReadfile = Readfile.ereadfile(SheetName);
		return eReadfile;
	}

	@AfterMethod
	public void End() {
		driver.close();
	}

}
