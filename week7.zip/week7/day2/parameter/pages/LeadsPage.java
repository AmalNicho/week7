package week7.day2.parameter.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.day2.parameter.base.Base;

public class LeadsPage extends Base {
	
	public LeadsPage(ChromeDriver Driver) {
		this.driver=Driver;
	}
	
	public CreateLeads Leadss() {
		driver.findElement(By.xpath("//a[text()='Create Lead']")).click();
		return new CreateLeads(driver);
	}

	public FindLeads FLeads() {
		driver.findElement(By.xpath("//a[text()='Find Leads']")).click();
		return new FindLeads(driver);
	}
	
	public MergeLeads MLeads() {
		driver.findElement(By.xpath("//a[text()='Merge Leads']")).click();
		return new MergeLeads(driver);
	}
}
