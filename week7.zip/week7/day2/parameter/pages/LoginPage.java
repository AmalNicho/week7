package week7.day2.parameter.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.day2.parameter.base.Base;

public class LoginPage extends Base {
		
	public LoginPage(ChromeDriver Driver) {
		this.driver=Driver;
		
	}
	
	public LoginPage typeusername() {
		driver.findElement(By.id("username")).sendKeys(property.getProperty("UserName"));
		return this;
	}

	public LoginPage typepassword() {
		driver.findElement(By.id("password")).sendKeys(property.getProperty("Password"));
		return this;
	}
	
	public WindowPage clicksubmit() {
		driver.findElement(By.className("decorativeSubmit")).click();
	return new WindowPage(driver);
	}
}

	