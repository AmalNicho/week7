package week7.day2.parameter.tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.day2.parameter.base.Base;
import week7.day2.parameter.pages.LoginPage;

public class DeleteLead extends Base {

	@BeforeTest
	public void setdeletefile() {
		SheetName = "DeleteLead";
	}

	@Test(dataProvider = "setfile")
	public void Dlead(String Cname, String Fname, String Lname) throws InterruptedException {
		new LoginPage(driver)
		.typeusername()
		.typepassword()
		.clicksubmit().leaftabs()
		.clickleads()
		.FLeads()
		.Flead(Fname)
		.Llead(Lname)
		.Clead(Cname)
		.Cli_FLeads()
		.sel_leads()
		.Dellead();

	}

}
