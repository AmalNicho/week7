package week7.day2.parameter.tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.day2.parameter.base.Base;
import week7.day2.parameter.pages.LoginPage;
public class DuplicateLeads extends Base {
	
	@BeforeTest
	public void setDuplLeadsfile() {
		SheetName="DuplicateLead";
	}
		
	
	
	@Test(dataProvider="setfile")
	public void Dleads(String Companyname,String Fname,String Lname,String Phonenumber) throws InterruptedException {
	
	new	LoginPage(driver)
	.typeusername()
	.typepassword()
	.clicksubmit()
	.leaftabs()
	.clickleads()
	.FLeads()
	.Flead(Fname)
	.Llead(Lname)
	.Clead(Companyname)
	.Cli_FLeads()
	.sel_leads()
	.Duplead()
	.typephonenumber(Phonenumber)
	.leads_submit()
	.Vlead();
		
		
		
	}

}
