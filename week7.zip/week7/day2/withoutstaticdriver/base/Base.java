package week7.day2.withoutstaticdriver.base;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;
import week7.day2.withoutstaticdriver.utility.Readfile;


public class Base {
	
	public ChromeDriver driver;
	public String SheetName;
	
	
		@Parameters({"URL"})
		@BeforeMethod
		public void Pre(String Url) {
			WebDriverManager.chromedriver().setup();
			 driver = new ChromeDriver();
			driver.get(Url);
			driver.manage().window().maximize();
		}
		
		
		
		@DataProvider
		public String[][] setfile() throws IOException {
			String[][] eReadfile = Readfile.ereadfile(SheetName);
			return eReadfile;
		}
	@AfterMethod
		public void End() {
			driver.close();
		}
		
		
	}


