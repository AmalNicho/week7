package week7.day2.withoutstaticdriver.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import week7.day2.withoutstaticdriver.base.Base;

public class ViewLeads extends Base {
	
	public ViewLeads(ChromeDriver Driver) {
		this.driver=Driver;
	}
	
	
	public void Vlead() {
			
		Assert.assertEquals(driver.getTitle(),"View Lead | opentaps CRM");
	}
	
	public EditPage Elead() {
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		return new EditPage(driver);
	}
	
	public DupLeads Duplead() {
		driver.findElement(By.xpath("//a[text()='Duplicate Lead']")).click();
		return new  DupLeads(driver);
	}
	
	public LeadsPage Dellead() {
		driver.findElement(By.xpath("//a[text()='Delete']")).click();
		return new LeadsPage(driver);
	}

}
