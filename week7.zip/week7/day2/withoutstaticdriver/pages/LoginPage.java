package week7.day2.withoutstaticdriver.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.day2.withoutstaticdriver.base.Base;

public class LoginPage extends Base {
	
	public LoginPage(ChromeDriver Driver) {
		this.driver=Driver;
	}
	
	public LoginPage typeusername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
		return this;
	}

	public LoginPage typepassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
		return this;
	}
	
	public WindowPage clicksubmit() {
		driver.findElement(By.className("decorativeSubmit")).click();
	return new WindowPage(driver);
	}
}

	