package week7.day2.withoutstaticdriver.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.day2.withoutstaticdriver.base.Base;

public class FindLeads extends Base {
	
	public FindLeads(ChromeDriver Driver) {
	this.driver=Driver;
	}
	
	public FindLeads Flead(String Fname) {
		driver.findElement(By.xpath("(//input[@name='firstName'])[3]")).sendKeys(Fname);
		return this;
	}

	public FindLeads Llead(String Lname) {
		driver.findElement(By.xpath("(//input[@name='lastName'])[3]")).sendKeys(Lname);
		return this;
	}
	
	public FindLeads Clead(String Cname) {
		driver.findElement(By.xpath("(//input[@name='companyName'])[2]")).sendKeys(Cname);
		return this;
	}
	
	public FindLeads Cli_FLeads() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
		return this;
	}
	
public ViewLeads sel_leads() {
	driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
	return new ViewLeads(driver);
}
}
