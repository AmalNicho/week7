package week7.day2.withoutstaticdriver.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.day2.withoutstaticdriver.base.Base;

public class WindowPage extends Base {
	
	public WindowPage(ChromeDriver Driver) {
		this.driver=Driver;
	}
	
	public HomePage leaftabs() {
	driver.findElement(By.xpath("//a[contains(text(),'CRM/SFA')]")).click();
return new HomePage(driver);
	}

}
