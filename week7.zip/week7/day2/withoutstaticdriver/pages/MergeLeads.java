package week7.day2.withoutstaticdriver.pages;

import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.day2.withoutstaticdriver.base.Base;

public class MergeLeads extends Base {
	
	public MergeLeads(ChromeDriver Driver) {
		this.driver=Driver;
	}

	ArrayList<String> arrayList = new ArrayList<String>();

	public MergeLeads find_first_contact() {
		driver.findElement(By.xpath("(//img[@src='/images/fieldlookup.gif'])[1]")).click();
		return this;

	}
	
	public MergeLeads find_second_contact() {
		driver.findElement(By.xpath("(//img[@src='/images/fieldlookup.gif'])[2]")).click();
		return this;

	}

	public MergeLeads window_handle(int windownumber) {
		Set<String> windowHandles = driver.getWindowHandles();
		arrayList.clear();
		arrayList.addAll(windowHandles);
		driver.switchTo().window(arrayList.get(windownumber));
		
		return this;
	}

	public MergeLeads typefirstname(String fname) {
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(fname);
		return this;
	}

	public MergeLeads typelastname(String lname) {
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lname);
		return this;
	}

	public MergeLeads typecompanyname(String cname) {
		driver.findElement(By.xpath("//input[@name='companyName']")).sendKeys(cname);
		return this;
	}

	public MergeLeads find() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
		return this;
	}

	public MergeLeads select_id() throws InterruptedException {
		driver.findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]")).click();
		
		return this;
	}

	public MergeLeads base_window() {
		driver.switchTo().window(arrayList.get(0));
		return this;
	}

	public ViewLeads click_merge() {
		driver.findElement(By.xpath("//a[text()='Merge']")).click();
		driver.switchTo().alert().accept();
		return new ViewLeads(driver);
	}

}