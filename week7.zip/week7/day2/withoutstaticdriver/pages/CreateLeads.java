package week7.day2.withoutstaticdriver.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.day2.withoutstaticdriver.base.Base;



public class CreateLeads extends Base {
	
	public CreateLeads(ChromeDriver Inwarddriver)
	{
		this.driver=Inwarddriver;
	}
	
	
	public CreateLeads typecompanyname(String Cname) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(Cname);
		return this;
	}

	public CreateLeads typefirstname(String Fname) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(Fname);
		return this;
	}

	public CreateLeads typelastname(String Lname) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(Lname);
		return this;
	}

	public ViewLeads cli_submit() {
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		return new ViewLeads(driver);
	}
}
