package week7.day2.withoutstaticdriver.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.day2.withoutstaticdriver.base.Base;

public class HomePage extends Base {
	
	public HomePage(ChromeDriver Driver) {
		this.driver=Driver;
	}
	
	public LeadsPage clickleads() {
		driver.findElement(By.xpath("//a[text()='Leads']")).click();
		return new LeadsPage(driver);
	}

}
