package week7.day2.withoutstaticdriver.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import week7.day2.withoutstaticdriver.base.Base;

public class DupLeads extends Base {
	
	public DupLeads(ChromeDriver inwarddriver) {
		this.driver=inwarddriver;
	}
	
	public DupLeads typephonenumber(String Phonenumber) {
		
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(Phonenumber);
		return this;
	}
	
	public ViewLeads leads_submit( ) {
		driver.findElement(By.xpath("//input[@value='Create Lead']")).click();
		return new ViewLeads(driver);
	}

}
