package week7.day2.withoutstaticdriver.tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.day2.withoutstaticdriver.base.Base;

import week7.day2.withoutstaticdriver.pages.LoginPage;

public class EditLeads extends Base {

	@BeforeTest
	public void SetEname( ) {
		SheetName="EditLead";
	}
	
	@Test(dataProvider="setfile")
	public void ELeads(String username,String password,String Cname,String Fname,String Lname,String Industry,String Title) throws InterruptedException
	{
		new LoginPage(driver)
		.typeusername(username)
		.typepassword(password)
		.clicksubmit()
		.leaftabs()
		.clickleads()
		.FLeads()
		.Flead(Fname)
		.Llead(Lname)
		.Clead(Cname)
		.Cli_FLeads()
		.sel_leads()
		.Elead().ELeadss(Industry)
		.title(Title)
		.Cli_Update()
		.Vlead();
		
	}
	}
	

