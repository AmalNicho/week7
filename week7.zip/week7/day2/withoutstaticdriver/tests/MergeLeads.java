package week7.day2.withoutstaticdriver.tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.day2.withoutstaticdriver.base.Base;
import week7.day2.withoutstaticdriver.pages.LoginPage;

public class MergeLeads extends Base
{
	
	@BeforeTest
	public void setMergefilenane() {
		SheetName="MergeLead";
	}
	
	@Test(dataProvider="setfile")
	
	public void Mleads(String UserName, String	Password,String	CompanyName,String FullName,String LastName,String FullName1,String LastName1) throws InterruptedException {
		
		new LoginPage(driver)
		.typeusername(UserName)
		.typepassword(Password)
		.clicksubmit()
		.leaftabs()
		.clickleads()
		.MLeads()
		.find_first_contact()
		.window_handle(1)
		.typefirstname(FullName)
		.typelastname(LastName)
		.typecompanyname(CompanyName)
		.find()
		.select_id()
		.base_window()
		.find_second_contact()
		.window_handle(1)
		.typefirstname(FullName1)
		.typelastname(LastName1)
		.typecompanyname(CompanyName)
		.find()
		.select_id()
		.base_window()
		.click_merge()
		.Vlead();
		
	}

}
