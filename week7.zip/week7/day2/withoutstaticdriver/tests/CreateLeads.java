package week7.day2.withoutstaticdriver.tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.day2.withoutstaticdriver.base.Base;
import week7.day2.withoutstaticdriver.pages.LoginPage;

public class CreateLeads extends Base {
	
	@BeforeTest
	public void Createfile() {
		SheetName="CreateLead";
	
	}
	
	@Test(dataProvider="setfile")
	public void CLeadsPostive(String username,String password,String Cname,String Fname,String Lname) {
		
		new LoginPage(driver)
		.typeusername(username)
		.typepassword(password)
		.clicksubmit()
		.leaftabs()
		.clickleads()
		.Leadss()
		.typecompanyname(Cname)
		.typefirstname(Fname)
		.typelastname(Lname)
		.cli_submit();
		
	}

}
