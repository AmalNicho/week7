package week7.day2.withoutstaticdriver.tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.day2.withoutstaticdriver.base.Base;
import week7.day2.withoutstaticdriver.pages.LoginPage;
public class DuplicateLeads extends Base {
	
	@BeforeTest
	public void setDuplLeadsfile() {
		SheetName="DuplicateLead";
	}
		
	
	
	@Test(dataProvider="setfile")
	public void Dleads(String username,String password,String Companyname,String Fname,String Lname,String Phonenumber) throws InterruptedException {
	
	new	LoginPage(driver)
	.typeusername(username)
	.typepassword(password)
	.clicksubmit()
	.leaftabs()
	.clickleads()
	.FLeads()
	.Flead(Fname)
	.Llead(Lname)
	.Clead(Companyname)
	.Cli_FLeads()
	.sel_leads()
	.Duplead()
	.typephonenumber(Phonenumber)
	.leads_submit()
	.Vlead();
		
		
		
	}

}
