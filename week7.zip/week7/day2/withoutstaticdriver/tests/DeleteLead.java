package week7.day2.withoutstaticdriver.tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.day2.withoutstaticdriver.base.Base;
import week7.day2.withoutstaticdriver.pages.LoginPage;

public class DeleteLead extends Base {

	@BeforeTest
	public void setdeletefile() {
		SheetName = "DeleteLead";
	}

	@Test(dataProvider = "setfile")
	public void Dlead(String username, String password, String Cname, String Fname, String Lname) throws InterruptedException {
		new LoginPage(driver)
		.typeusername(username)
		.typepassword(password)
		.clicksubmit().leaftabs()
		.clickleads()
		.FLeads()
		.Flead(Fname)
		.Llead(Lname)
		.Clead(Cname)
		.Cli_FLeads()
		.sel_leads()
		.Dellead();

	}

}
