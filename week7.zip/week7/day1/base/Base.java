package week7.day1.base;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;
import week7.day1.utility.Readfile;

public class Base {
	public String SheetName;
	
	public static ChromeDriver driver;
	@Parameters({"URL"})
	@BeforeMethod
	public void start_browser(String Url) {
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.get(Url);
		driver.manage().window().maximize();
	}
	
	@AfterMethod
	public void end_browser() {
		driver.close();
}
	
	@DataProvider
	public String[][] setfile() throws IOException {
		String[][] eReadfile = Readfile.EReadfile(SheetName);
		return eReadfile;
	}

}
