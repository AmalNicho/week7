package week7.day1.utility;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Readfile {
	
	
	public static String[][] EReadfile(String SheetName) throws IOException {
	
	XSSFWorkbook excel = new XSSFWorkbook("./TestData/AllDetails.xlsx");
	XSSFSheet sheet = excel.getSheet(SheetName);
	XSSFRow row = sheet.getRow(0);
	short lastCellNum = row.getLastCellNum();
    int lastRowNum = sheet.getLastRowNum();	
    String[][] read= new String[lastRowNum][lastCellNum];

    for (int i = 1; i <= lastRowNum; i++) {
    	XSSFRow row2 = sheet.getRow(i);
    	for (int j = 0; j < lastCellNum; j++) {
    		XSSFCell cell = row2.getCell(j);
			String value = cell.getStringCellValue();
			read[i-1][j]=value;
		}
		
	}
    excel.close();
    return read;
}

}