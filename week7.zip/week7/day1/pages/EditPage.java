package week7.day1.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import week7.day1.base.Base;

public class EditPage extends Base {

	public EditPage ELeadss(String Industry) {

		WebElement dropdown = driver.findElement(By.id("updateLeadForm_industryEnumId"));
		Select x = new Select(dropdown);
		x.selectByVisibleText(Industry);
		return this;

	}

	public EditPage title(String title) {
		driver.findElement(By.id("updateLeadForm_generalProfTitle")).sendKeys(title);
		return this;
	}

	public ViewLeads Cli_Update() {
		driver.findElement(By.xpath("//input[@value='Update']")).click();
		return new ViewLeads();
	}

}
