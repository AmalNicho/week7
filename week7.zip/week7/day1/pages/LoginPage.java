package week7.day1.pages;

import org.openqa.selenium.By;

import week7.day1.base.Base;

public class LoginPage extends Base {
	
	public LoginPage typeusername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
		return this;
	}

	public LoginPage typepassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
		return this;
	}
	
	public WindowPage clicksubmit() {
		driver.findElement(By.className("decorativeSubmit")).click();
	return new WindowPage();
	}
}

	