package week7.day1.pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import week7.day1.base.Base;

public class ViewLeads extends Base {
	
	public void Vlead() {
			
		Assert.assertEquals(driver.getTitle(),"View Lead | opentaps CRM");
	}
	
	public EditPage Elead() {
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		return new EditPage();
	}
	
	public DupLeads Duplead() {
		driver.findElement(By.xpath("//a[text()='Duplicate Lead']")).click();
		return new  DupLeads();
	}
	
	public LeadsPage Dellead() {
		driver.findElement(By.xpath("//a[text()='Delete']")).click();
		return new LeadsPage();
	}

}
