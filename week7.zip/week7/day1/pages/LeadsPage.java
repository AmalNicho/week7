package week7.day1.pages;

import org.openqa.selenium.By;

import week7.day1.base.Base;

public class LeadsPage extends Base {
	
	public CreateLeads Leadss() {
		driver.findElement(By.xpath("//a[text()='Create Lead']")).click();
		return new CreateLeads();
	}

	public FindLeads FLeads() {
		driver.findElement(By.xpath("//a[text()='Find Leads']")).click();
		return new FindLeads();
	}
	
	public MergeLeads MLeads() {
		driver.findElement(By.xpath("//a[text()='Merge Leads']")).click();
		return new MergeLeads();
	}
}
