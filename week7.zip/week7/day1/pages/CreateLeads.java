package week7.day1.pages;

import org.openqa.selenium.By;

import week7.day1.base.Base;

public class CreateLeads extends Base {
	
	public CreateLeads typecompanyname(String Cname) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(Cname);
		return this;
	}

	public CreateLeads typefirstname(String Fname) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(Fname);
		return this;
	}

	public CreateLeads typelastname(String Lname) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(Lname);
		return this;
	}

	public ViewLeads cli_submit() {
		driver.findElement(By.xpath("//input[@name='submitButton']")).click();
		return new ViewLeads();
	}
}
