package week7.day1.pages;

import org.openqa.selenium.By;

import week7.day1.base.Base;

public class HomePage extends Base {
	public LeadsPage clickleads() {
		driver.findElement(By.xpath("//a[text()='Leads']")).click();
		return new LeadsPage();
	}

}
