package week7.day1.pages;

import org.openqa.selenium.By;

import week7.day1.base.Base;

public class WindowPage extends Base {
	
	public HomePage leaftabs() {
	driver.findElement(By.xpath("//a[contains(text(),'CRM/SFA')]")).click();
return new HomePage();
	}

}
